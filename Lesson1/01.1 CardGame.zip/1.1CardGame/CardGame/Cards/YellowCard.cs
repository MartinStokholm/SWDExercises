﻿namespace CardGame.Cards
{
    public class YellowCard : Card
    {
        public YellowCard(int number) :
            base()
        {
            Number = number;
            Suit = 4;
            SuitName = "Yellow";
        }
    }
}
