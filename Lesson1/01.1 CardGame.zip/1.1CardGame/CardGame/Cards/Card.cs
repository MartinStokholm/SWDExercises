﻿namespace CardGame.Cards
{
    public abstract class Card
    {
        public int GetValue()
        {
            return Number * Suit;
        }

        public override string ToString()
        {
            return SuitName + " " + Number + " (" + GetValue() + ")";
        }

        public int Number { get; protected set; }

        public int Suit { get; protected set; }

        public string? SuitName { get; protected set; }
    }
}
