﻿namespace CardGame.Cards
{
    class BlueCard : Card
    {
        public BlueCard(int number)
            : base()
        {
            Number = number;
            Suit = 2;
            SuitName = "Blue";
        }
    }
}
