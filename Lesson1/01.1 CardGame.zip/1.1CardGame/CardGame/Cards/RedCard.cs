﻿namespace CardGame.Cards
{
    public class RedCard : Card
    {
        public RedCard(int number)
            : base()
        {
            Number = number;
            Suit = 1;
            SuitName = "Red";
        }
    }
}
