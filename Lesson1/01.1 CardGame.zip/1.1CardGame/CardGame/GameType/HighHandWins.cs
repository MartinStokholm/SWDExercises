﻿using System.Collections.Generic;

namespace CardGame.GameType
{
    public class HighHandWins : IGameType
    {
        public void AnnounceWinner(List<Player> players)
        {
            Player winner = players[0];
            foreach (var player in players)
            {
                if (player.TotalHandValue() > winner.TotalHandValue())
                {
                    winner = player;
                }
            }
            System.Console.WriteLine("Winner is: " + winner.Name);
        }
    }
}
