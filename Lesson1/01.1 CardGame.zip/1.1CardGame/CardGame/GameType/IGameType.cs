﻿using System.Collections.Generic;

namespace CardGame.GameType
{
    public interface IGameType
    {
        void AnnounceWinner(List<Player> players);
    }
}
