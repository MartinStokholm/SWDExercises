﻿using System;
using System.Collections.Generic;
using CardGame.Cards;

namespace CardGame
{
    public class Deck
    {
        private readonly List<Card> cards = new List<Card>();
        private readonly Random r = new Random();

        public Deck()
        {
            CreateCards();
            Shuffle();
        }

        private void Shuffle()
        {
            int numberOfCards = cards.Count;

            // swap two random cards a large number of times.
            for (int i = 0; i < numberOfCards * 50; i++)
            {
                int index1 = r.Next(0, numberOfCards - 1);
                int index2 = r.Next(0, numberOfCards - 1);

                Card temp = cards[index1];
                cards[index1] = cards[index2];
                cards[index2] = temp;
            }
        }

        private void CreateCards()
        {
            for (int i = 1; i <= 8; i++)
            {
                cards.Add(new RedCard(i));
                cards.Add(new BlueCard(i));
                cards.Add(new GreenCard(i));
                cards.Add(new YellowCard(i));
                cards.Add(new GoldCard(i));
            }
        }

        public void DealTo(Player player, int numberOfCardsToDeal)
        {
            for (int i = 0; i < numberOfCardsToDeal; i++)
            {
                int indexOfCardToGive = r.Next(0, cards.Count);
                Card c = cards[indexOfCardToGive];
                player.AcceptCard(c);
                cards.Remove(c);
                
            }
        }
    }
}
