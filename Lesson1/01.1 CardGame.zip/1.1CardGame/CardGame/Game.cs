﻿using System.Collections.Generic;
using CardGame.GameType;

namespace CardGame
{
    public class Game
    {
        private List<Player> players = new List<Player>();
        private bool gameIsStarted = false;
        private readonly Deck deck;
        private int NUMBER_OF_CARDS_TO_DEAL = 5;
        private readonly IGameType gameType;

        public Game(Deck deck, IGameType gameType)
        {
            this.deck = deck;
            this.gameType = gameType;
        }

        public void AcceptPlayer(Player player)
        {
            if (!gameIsStarted)
            {
                players.Add(player);
            }
            else
            {
                // Maybe report on the console that the game has started?
                // Or throw an exception?
                // The requirements does not say anything about this scenario
                // so maybe we should go back to the product owner and ask.
            }
        }

        public void Start()
        {
            gameIsStarted = true;
            DealCards();
        }

        private void DealCards()
        {
            foreach (var player in players)
            {
                deck.DealTo(player, NUMBER_OF_CARDS_TO_DEAL);
            }
        }

        public void AnnounceWinner()
        {
            if (!gameIsStarted)
            {
                System.Console.WriteLine("The game is not started yet.");
            }
            else
            {
                gameType?.AnnounceWinner(players);
            }
        }
    }
}
