﻿using System.Collections.Generic;
using System.Text;
using CardGame.Cards;

namespace CardGame  
{
    public class Player
    {
        public Player(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

        protected readonly List<Card> cards = new List<Card>();
        public virtual void AcceptCard(Cards.Card card)
        {
            cards.Add(card);
        }

        public int TotalHandValue()
        {
            int value = 0;
            foreach (var card in cards)
            {
                value += card.GetValue();
            }
            return value;
        }

        public string ShowHand()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(Name + ": (total: " + TotalHandValue() + ") ");
            foreach (var card in cards)
            {
                builder.Append(card.ToString());
                builder.Append("; ");
            }
            builder.Append("\r\n");
            return builder.ToString();
        }
    }
}
